#include<bits/stdc++.h>
using namespace std;

struct node{
	int j;
	string s;
	bool c;
}a[510];
int n,q;

signed main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i].j;
		a[i].s="AAA";
		a[i].c=0;
	}
	while(q--){
		char op;
		cin>>op;
		if(op=='W'){
			int l,r,t,sum1=0,sum2=0;
			cin>>l>>r>>t;
			for(int i=l;i<=r;i++){
				if(!a[i].c){
					sum1++;
					if(a[i].j<t){
						sum2++;
						a[i].c=1;
					}else{
						a[i].j++;
					}
				}
			}
			cout<<sum1<<' '<<sum2<<endl;
		}else if(op=='A'){
			int l,r,k,sum=0;
			cin>>l>>r>>k;
			for(int i=l;i<=r;i++){
				if(a[i].c){
					sum++;
					a[i]={k,"AAA",0};
				}
			}
			if(sum==0){
				cout<<"no add"<<endl;
			}else if(sum==1){
				cout<<"Add 1 soldier"<<endl;
			}else{
				cout<<"Add "<<sum<<" soldiers"<<endl;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

