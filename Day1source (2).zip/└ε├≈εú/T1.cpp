#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,m,k,a[1010],l[20],c[20],ans=INT_MAX;
bool vis[1010];

void dfs(int dep,int sc,int ks){
	if(sc>ans){
		return;
	}
	if(dep>k){
		if(!ks){
			ans=sc;
		}
		return;
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			int k=i,kk=0;
			while(a[i]+l[dep]>=a[k]){
				vis[i]=1;
				kk++;
				k++;
			}
			dfs(dep+1,sc+c[i],ks-kk);
			while(a[i]+l[dep]>=a[k]){
				vis[i]=0;
				k++;
			}
		}
	}
	dfs(dep+1,sc,ks);
	return;
}

signed main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+1+n);
	for(int i=1;i<=k;i++){
		cin>>l[i]>>c[i];
	}
	dfs(1,0,n);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
