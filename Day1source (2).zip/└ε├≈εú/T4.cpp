#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,a[500010],vis[210],mx,s,l,r;

bool check(int k){
	if(k==1){
		return false;
	}
	for(int i=1;i<=k;i++){
		vis[a[i]]++;
		if(vis[a[i]]>mx){
			mx=vis[a[i]];
			s=1;
		}else if(vis[a[i]]==mx){
			s++;
		}
	}
	int lo=1,hi=k;
	for(;hi<=n;){
		if(s>1){
			l=lo;
			r=hi;
			return true;
		}
		vis[lo]--;
		if(vis[lo++]==mx){
			s--;
		}
		if(s==0){
			mx=0;
			for(int i=0;i<=200;i++){
				if(vis[i]>mx){
					mx=vis[i];
					s=1;
				}else if(vis[i]==mx){
					s++;
				}
			}
		}
		vis[++hi]++;
		if(vis[hi]>mx){
			mx=vis[hi];
			s=1;
		}else if(vis[hi]==mx){
			s++;
		}
	}
	return false;
}

signed main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	int hi=n,lo=1;
	while(lo<hi){
		int mid=(lo+hi)>>1;
		if(check(mid)){
			lo=mid;
		}else{
			hi=mid-1;
		}
	}
	if(lo==1){
		cout<<-1;
		return 0;
	}
	cout<<l<<' '<<r;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
