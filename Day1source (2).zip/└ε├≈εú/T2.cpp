#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,a[1010],sum;
map<int,bool> vis;

signed main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		vis[a[i]]=true;
	}
	sort(a,a+n);
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			int pre=a[j]-a[i];
			if(vis[a[j]+pre]&&vis[a[j]+pre+pre]){
				sum++;
			}
			double pre2=1.0*a[j]/a[i];
			if(vis[(int)a[j]*pre2]&&vis[(int)a[j]*pre2*pre2]){
				sum++;
			}
		}
	}
	cout<<sum;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

