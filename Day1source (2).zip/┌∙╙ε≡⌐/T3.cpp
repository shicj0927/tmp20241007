#include<bits/stdc++.h>
using namespace std;
int n,q,a[505],l,r,t,sum,die;
bool b[505];
char c;
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++) cin>>a[i],b[i]=1;
	while(q--){
		cin>>c;
		if(c=='W'){
			cin>>l>>r>>t;
			sum=die=0;
			for(int i=l;i<=r;i++){
				if(b[i]) sum++;
				if(a[i]<t){
					b[i]=0;
					die++;
				}
				else{
					a[i]++;
				}
			}
			cout<<sum<<' '<<die<<endl;
		}
		if(c=='A'){
			cin>>l>>r>>t;
			sum=0;
			for(int i=l;i<=r;i++){
				if(!b[i]){
					b[i]=1;
					a[i]=t;
					sum++;
				}
			}
			if(sum==0){
				cout<<"no add"<<endl;
			}
			else if(sum==1){
				cout<<" Add 1 soldier"<<endl;
			}
			else cout<<"Add "<<sum<<" soldiers"<<endl;
		}
	}
	return 0;
}
