#include<bits/stdc++.h>
using namespace std;
#define int long long
#define inf 10000000000000000ll
int n,m,k,a[5001];
int c[5001],l[5001];
int ans=inf;
struct node{
	int id,c,l;
};
bool check(vector<node>bs){
	return false;
}
signed main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=k;i++){
		cin>>c[i]>>l[i];
	}
	for(int i=0;i<(1<<k);i++){
		int now=0;
		vector<node>used;
		used.clear();
		for(int j=1;j<=k;j++){
			if((i>>(j-1))|1){
				used.push_back({j,c[j],l[j]});
				now+=c[j];
			}
		}
		if(check(used)){
			ans=min(ans,now);
		}
	}
	if(ans==inf){
		cout<<"poor A!"<<endl;
	}
	else{
		cout<<ans<<endl;
	}
	return 0;
}