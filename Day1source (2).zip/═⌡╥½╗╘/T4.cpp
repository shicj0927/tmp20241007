#include<bits/stdc++.h>
using namespace std;
long long read(){
long long sgn=1,num=0;
char ch=getchar();
while(ch<'0'||ch>'9'){
if(ch=='-')sgn=-1;
ch=getchar();
}
while(ch>='0'&&ch<='9'){
num=(num<<3)+(num<<1)+ch-'0';
ch=getchar();
}
return sgn*num;
}
void write(long long n,bool p){
if(n<0){putchar('-');n=-n;}
if(n==0){if(p)putchar('0');
return; }
write(n/10,0);putchar(n%10+'0');
}
int main(){freopen("T4.in","r",stdin);
freopen("T4.out","w",stdout);
cout<<"-1";
return 0;}
