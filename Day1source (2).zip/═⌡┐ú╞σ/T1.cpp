#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[1005],l[15],c[15];
long long f[1005];
struct mood{
	int l,c;
}mu[15];
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=k;i++){
		cin>>mu[i].l>>mu[i].c;
	}
	cout<<"poor A!";
	return 0;
}
