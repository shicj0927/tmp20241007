#include <bits/stdc++.h>
#define int long long

using namespace std;

const int N = 1005;
const int M = 15;

int n, m, k, a[N], l[N], c[N];

inline void sol() {
	cin >> n >> m >> k;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= k; i++) {
		cin >> l[i] >> c[i];
	}
	cout << "poor A!";
}

signed main() {
	freopen("T1.in", "r", stdin);
	freopen("T1.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
//	init();
	int T = 1;
//	cin >> T;
	while (T--) sol();
	return 0;
}
