#include<bits/stdc++.h>
using namespace std;
char op;
int n,q,l,r,t;
int a[505];
bool vis[505];
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	cin>>n>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	memset(vis,1,sizeof(vis));
	while(q--){
		cin>>op>>l>>r>>t;
		if(op=='W'){
			int num=0,kill=0;
			for(int i=l;i<=r;i++){
				if(vis[i]){
					if(a[i]<t) kill++,vis[i]=0;
					else a[i]++;
					num++;
				}
			}
			cout<<num<<' '<<kill<<endl;
		}
		else{
			int num=0;
			for(int i=l;i<=r;i++){
				if(!vis[i]){
					vis[i]=1;
					a[i]=t;
					num++;
				}
			}
			if(num==0) cout<<"no add";
			else{
				cout<<"Add "<<num<<" soldier";
				if(num>1) cout<<'s';
			}
			cout<<endl;
		}
	}
	return 0;
}
