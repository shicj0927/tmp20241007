#include<bits/stdc++.h>
using namespace std;
long long n,a[1005],z,f1,f2,f3=0,sum=0;
bool cmp(int x,int y){
	if(abs(x)==abs(y))return x<y;
	return abs(x)<abs(y);
}
int pd(int x){
	for(int i=1;i*i*i<=abs(x);i++){
		if(i*i*i==abs(x))return abs(x)/x*i;
	}
	return 0;
}
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n-1;i++){
		for(int j=i+1;j<=n;j++){
			if(a[j]%a[i]==0){
				z=pd(a[j]/a[i]);
				if(z!=0){
					f1=0;
					f2=0;
					for(int k=i+1;k<=j-1;k++){
						if(a[k]==a[i]*z*z&&(f1||z!=1))f2++;
						if(a[k]==a[i]*z)f1++;
					}
					sum+=f1*f2/(z==1?2:1);
				}
			}
			if((a[j]-a[i])%3==0){
				z=(a[j]-a[i])/3;
				f1=0;
				f2=0;
				if(a[i]!=f3)f3=0;
				if(z==0){
					if(f3==0){
						f3=a[i];
						for(int k=1;k<=j;k++){
							if(a[k]==a[i])f1++;
						}
						sum+=f1*(f1-1)*(f1-2)*(f1-3)/24;
					}
				}else{
					for(int k=1;k<=j;k++){
						if(a[k]==a[i]+z)f1=1;
						if(a[k]==a[i]+z+z)f2=1;
					}
					if(f1&&f2)sum++;
				}
			}
		}
	}
	cout<<sum;
	return 0;
}
