#include<bits/stdc++.h>
using namespace std;
int a[510];
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	int n,q;
	scanf("%d%d",&n,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]); 
	}
	while(q--){
		char s;
		int a,b,c;
		cin>>s>>a>>b>>c;
		if(s=='W'){
			printf("%d\n",b-a+1);
		}
		else{
			printf("no add\n");
		}
	}
	return 0;
}
