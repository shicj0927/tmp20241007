#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	printf("0\n");
	return 0;
}
