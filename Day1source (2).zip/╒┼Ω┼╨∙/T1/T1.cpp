#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[1010],l1[1010],c[1010],l2[1010],p=1,ans;
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i = 1;i<=n;i++){
		int tmp;
		cin>>tmp;
		a[tmp]=1;
	}
	for(int i = 1;i<=m;i++){
		if(a[i]==1){
			l2[p]++;
			while(a[++i]==1) l2[p]++;
			p++;
		}
	}
	p--;
	sort(l2+1,l2+1+p);
	for(int i = 1;i<=k;i++){
		cin>>l1[i]>>c[i];
		int j = i;
		while(j>1&&(c[j]<c[j-1]||c[j]==c[j-1]&&l1[j]>l1[j-1])){
			swap(l1[j],l1[j-1]);
			swap(c[j],c[j-1]);
			j--;
		}
	}
	for(int i = p;i>=1;i--){
		for(int j = 1;j<=k;j++){
			if(l1[j]>=l2[i]){
				ans+=c[j];
				c[j]=0;
				l1[j]=0;
				l2[i]=0;
				break;
			}
		}
		if(l2[i]){
			cout<<"poor A";
			return 0;
		}
	}
	cout<<ans;
	return 0;
}

