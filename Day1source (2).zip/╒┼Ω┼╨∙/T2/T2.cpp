#include<bits/stdc++.h>
using namespace std;
int n,ans;
double x[60];
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	if(n<=50){
		for(int i = 1;i<=n;i++){
			scanf("%lf",&x[i]);
		} 
		sort(x+1,x+1+n);
		for(int a = 1;a<=n-3;a++){
			for(int b = a+1;b<=n-2;b++){
				for(int c = b+1;c<=n-1;c++){
					for(int d = c+1;d<=n;d++){
						if(x[d]-x[c]==x[c]-x[b]&&x[c]-x[b]==x[b]-x[a]){
							ans++;
						}
					}
				}
			}
		}
		cout<<ans;
		return 0;
	}
	return 0;
}

