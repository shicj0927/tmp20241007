#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[1001],l[1001],c[1001],b[1001];
int cost=0x3f3f3f3f;
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;++i)
		cin>>a[i],b[a[i]]=1;
	for(int i=1;i<=m;++i)
		b[i]+=b[i-1];
	sort(a+1,a+1+n);
	for(int i=1;i<=k;++i)
		cin>>l[i]>>c[i];
	for(int i=1;i<=1<<k;++i){
		int s=0,s2=0,t=i;
		while(t){
			int p=log2(t&-t)+1;
			s+=l[p];
			s2+=c[p];
			t-=t&-t;
		}
		if(s>=b[m])cost=min(cost,s2);
	}
	cout<<cost;
}
