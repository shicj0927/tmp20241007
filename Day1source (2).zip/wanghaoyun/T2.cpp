#include<bits/stdc++.h>
#define eps 1e-10
using namespace std;
int n,ans,a[1001];
map<int,int>mp;
map<pair<pair<int,int>,pair<int,int>>,int>sum;
bool cmp(int x,int y){
	return abs(x)<abs(y); 
}
int calc(int x){
	if(x<4)return 0;
	int s=1,t=x;
	while(x>4){
		s*=x;x--;	
	}
	x=t;
	while(x>4){
		s/=(x-4);x--;	
	}
	return s; 
}
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;++i)
		cin>>a[i],mp[a[i]]++;
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j){
			mp[a[i]]--;
			mp[a[j]]--;
			int flag=0; 
//			if(abs(a[i])>abs(a[j]))flag=1,swap(i,j);
			int k=0;
			if(a[i]*a[j]!=0)
			if(a[i]*a[i]%a[j]==0&&a[j]*a[j]%a[i]==0){
				int x=a[i]*a[i]/a[j],y=a[j]*a[j]/a[i];
				if((mp[x]>=1&&mp[y]>=1&&x!=y)||(x==y&&mp[x]>=2))sum[{{x,a[i]},{a[j],y}}]=max(sum[{{x,a[i]},{a[j],y}}],(x==y&&x==a[i]&&x==a[j]?calc(mp[x]+2):mp[x]*mp[y]*(1+mp[a[i]])*(1+mp[a[j]])));
			}
//			if(k!=0)k=1.0/k;
//			swap(i,j); 
//			int x=a[i]/k,y=a[j]*k;
//			if(fabs(x-floor(x))<eps||fabs(x-ceil(x))<eps)
//			if(fabs(y-floor(y))<eps||fabs(y-ceil(y))<eps)
//			if((mp[x]>=1&&mp[y]>=1&&x!=y)||(x==y&&mp[x]>=2))sum[{{x,a[i]},{a[j],y}}]=max(sum[{{x,a[i]},{a[j],y}}],(x==y&&x==a[i]&&x==a[j]?:mp[x]*mp[y]*max(1,1+mp[a[i]])*max(1,1+mp[a[j]])));
//			swap(i,j); 
			k=a[j]-a[i];
			int x=a[i]-k,y=a[j]+k;
			if((mp[x]>=1&&mp[y]>=1&&x!=y)||(x==y&&mp[x]>=2))sum[{{x,a[i]},{a[j],y}}]=max(sum[{{x,a[i]},{a[j],y}}],(x==y&&x==a[i]&&x==a[j]?calc(mp[x]+2):mp[x]*mp[y]*(1+mp[a[i]])*(1+mp[a[j]])));
			mp[a[i]]++;
			mp[a[j]]++;
//			if(f==1)cout<<i<<' '<<j<<'\n';
		}
//	cout<<sum.size()<<'\n';
	for(auto i:sum){
		ans+=i.second;
//		cout<<i.first.first.first<<' '<<i.first.first.second<<' '<<i.first.second.first<<' '<<i.first.second.second<<'\n'; 
	} 
	cout<<ans;
}
