#include<bits/stdc++.h>
#define MAXN 1005
using namespace std;
long long read(){long long x=0,sgn=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')sgn=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch&15);ch=getchar();}return x*sgn;}
void write(long long n,bool p){if(n<0){putchar('-');n=-n;}if(n==0){if(p)putchar('0');return;}write(n/10,0);putchar(n%10+'0');}

int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	printf("-1");
	return 0;
}
