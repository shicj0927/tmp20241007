#include<bits/stdc++.h>
#define MAXN 1005
using namespace std;
long long read(){long long x=0,sgn=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')sgn=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<3)+(x<<1)+(ch&15);ch=getchar();}return x*sgn;}
void write(long long n,bool p){if(n<0){putchar('-');n=-n;}if(n==0){if(p)putchar('0');return;}write(n/10,0);putchar(n%10+'0');}
long long n,m,k,nex[1005],a[1005],dp[1005][1030],l[12],c[12],p=0xffffffffffffff,ans,to,to2;
bool vis[1005][1030];
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	n=read();m=read();k=read();ans=p;
	for(int i=1;i<=n;i++)a[i]=read();
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
		for(int j=a[i-1]+1;j<=a[i];j++)
			nex[j]=a[i];
	for(int i=a[n]+1;i<=m+2;i++)nex[i]=m+2;
	for(int i=0;i<=m;i++)
		for(int j=(1<<k)-1;j>=0;j--)
			dp[i][j]=p;
	for(int i=0;i<a[1];i++){vis[i][0]=1;dp[i][0]=0;}
	for(int i=0;i<k;i++){l[i]=read();c[i]=read();}
	for(int i=0;i<=m;i++){
		for(int j=(1<<k)-1;j>=0;j--){
			if(!vis[i][j])continue;
			for(int ii=0;ii<k;ii++){
				if((1<<ii)&j)continue;
				to=i+l[ii];
				if(to>m)continue;
				to2=j|(1<<ii);
				if(dp[i]+c[ii]<dp[to]){
					dp[to][to2]=dp[i][j]+c[ii];
					vis[to][to2]=1;
					for(int jj=to+1;nex[jj]!=jj;jj++){
						if(dp[jj][to2]<=dp[jj-1][to2]&&vis[jj][to2])break;
						dp[jj][to2]=dp[jj-1][to2];
						vis[jj][to2]=1;
					}
				}
			}
		}
	}
	for(int i=a[n];i<=m;i++)
		for(int j=(1<<k)-1;j>=0;j--)
			if(vis[i][j])ans=min(ans,dp[i][j]);
	//for(int i=1;i<=m;i++)printf("%d %d% %lld\n",i,vis[i],dp[i]);
	if(ans==p)printf("poor A!");
	else printf("%lld",ans);
	return 0;
}
