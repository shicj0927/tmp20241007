#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
int a[N],maxn,n,ml,mr,mp[N];
int solve(int id){
	for(int i=1;i<=200;i++)
		mp[i]=0;
	int m1=0,m2=0;
	for(int i=id;i<=n;i++){
		mp[a[i]]++;
		if(a[i]==m1) continue;
		if(mp[a[i]]>mp[m1]){
			m2=m1;
			m1=a[i];
		}
		else if(mp[a[i]]>mp[m2]){
			m2=a[i];
		}
		if(mp[m1]==mp[m2])
			maxn=max(maxn,i-id+1);
	}	
	return maxn;
}
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	int ans=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=n;i>=1;i--){
		maxn=-1;
		solve(i);
		if(maxn>=ans){
			ans=maxn;
			ml=i;
			mr=i+maxn-1;
		}
	}
	if(ans==0) cout<<-1;
	else cout<<ml<<' '<<mr;
}
//383 4909

