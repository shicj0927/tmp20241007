#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=5e5+10;
int n,a[maxn],cnt[205][maxn],len[205],maxc,al,ar;
signed main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		maxc=max(maxc,a[i]);
		len[a[i]]+=1;
		for(int j=1;j<=maxc;j++){
			cnt[j][i]=len[j];
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=n;j>=i+1;j--){
			int l=j-i;
			if(l<=ar-al) break;
			int flag=0,maxa=0,maxb=0;
			for(int k=1;k<=maxc;k++){
				int x=cnt[k][j]-cnt[k][i-1];
				if(x==maxa) maxb++;
				if(x>maxa){
					maxa=x;
					maxb=1;
				}
			}
			if(maxb>=2){
				al=i;
				ar=j;
			}
		}
	}
	if(ar-al<=1) printf("-1");
	else printf("%d %d",al,ar);
	return 0;
}
