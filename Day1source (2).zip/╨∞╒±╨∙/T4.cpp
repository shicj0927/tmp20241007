#include <bits/stdc++.h>
using namespace std;
int maxlen,L = 1005,R;
int n,t[205],a[25];
int main(){
	freopen ("T4.in","r",stdin);
	freopen ("T4.out","w",stdout);
	cin >> n;
	for (int i = 1 ; i <= n ; i++) cin >> a[i];
	for (int i = 1 ; i <= n ; i++){
		for (int j = i + 1 ; j <= n ; j++){
			memset (t,0,sizeof(t));
			int maxn = 0,cnt = 0;
			for (int k = i ; k <= j ; k++){
				t[a[k]]++;
				maxn = max(maxn,t[a[k]]);
			}
			for (int k = 1 ; k <= 200 ; k++){
				if (maxn == t[k]) cnt++;
			}
			if (cnt > 1 && maxlen < j - i + 1){
				maxlen = j - i + 1;
				L = i;
				R = j;
			}
			if (cnt > 1 && maxlen == j - i + 1 && i < L){
				L = i;
				R = j;
			}
		}
	}
	if (L == 1005) cout << "-1";
	else cout << L << ' ' << R;
	return 0;
}
