#include <bits/stdc++.h>
using namespace std;
int n,len,k,x,t[1005],que[15];
int zh[1005];
struct wood{
	int l,c;
};
wood w[15];
void init(){
	cin >> n >> len >> k;
	for (int i = 1 ; i <= n ; i++){
		cin >> x;
		zh[x] = 1;
	}
	for (int i = 1 ; i <= k ; i++){
		cin >> w[i].l >> w[i].c;
	}
}
void getque(){
	int cnt = 0;
	for (int i = 1 ; i <= len ; i++){
		if (zh[i]) cnt++;
		else{
			t[cnt]++;
			cnt = 0;
		}
	}
	if (cnt) t[cnt]++;
	int qcnt = 0;
	for (int i = 1 ; i <= len ; i++){
		while (t[i]){
			que[++qcnt] = i;
			t[i]--;
		}
	}
	for (int i = 1 ; i <= qcnt ; i++) cout << que[i] << ' ';
}
int main(){
	freopen ("T1.in","r",stdin);
	freopen ("T1.out","w",stdout);
	init();
	getque();
	cout << "poor A!";
	return 0;
}
