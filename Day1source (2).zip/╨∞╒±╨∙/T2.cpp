#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const double inf = 0.00001;
int n,s[1005];
ll ans;
bool pd1 (int a,int b,int c,int d){
	return (d - c == c - b && c - b == b - a);
}
bool pd2 (int a,int b,int c,int d){
	double u = abs(1.0 * d / c - 1.0 * c / b);
	double v = abs(1.0 * c / b - 1.0 * b / a);
	return (u <= inf && v <= inf);
}
int main(){
	freopen ("T2.in","r",stdin);
	freopen ("T2.out","w",stdout);
	cin >> n;
	for (int i = 1 ; i <= n ; i++) cin >> s[i];
	sort (s + 1,s + n + 1);
	for (int a = 1 ; a <= n - 3 ; a++)
		for (int b = a + 1 ; b <= n - 2 ; b++)
			for (int c = b + 1 ; c <= n - 1 ; c++)
				for (int d = c + 1 ; d <= n ; d++)
					if (pd1(s[a],s[b],s[c],s[d]) || pd2(s[a],s[b],s[c],s[d]))
				    	ans++;
	cout << ans;
	return 0;
}
