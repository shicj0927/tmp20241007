#include <bits/stdc++.h>
using namespace std;
const int N = 505;
int n,q;
int a[N];
char op;
void work1(){
	int l,r,t,sum = 0;
	int z = 0,w = 0;
	cin >> l >> r >> t;
	for (int i = l ; i <= r ; i++){
		if (a[i] == -1) continue;
		w++;
		if (a[i] < t){
			a[i] = -1;
			z++;
		}else{
			a[i]++;
		}
	}
	cout << w << ' ' << z << endl;
}
void work2(){
	
}
void work3(){
	
}
void work4(){
	
}
void work5(){
	int l,r,k,x = 0;
	cin >> l >> r >> k;
	for (int i = l ; i <= r ; i++){
		if (a[i] == -1){
			a[i] = k;
			x++;
		}
	}
	if (!x) puts("no add");
	else if (x == 1) cout << "Add " << x << " soldier\n";
	else cout << "Add " << x << " soldiers\n";
}
int main(){
	freopen ("T3.in","r",stdin);
	freopen ("T3.out","w",stdout);
	cin >> n >> q;
	for (int i = 1 ; i <= n ; i++) cin >> a[i];
	for (int i = 1 ; i <= q ; i++){
		cin >> op;
		if (op == 'W') work1();
		else if (op == 'C') work2();
		else if (op == 'S') work3();
		else if (op == 'E') work4();
		else if (op == 'A') work5();
	}
	return 0;
}
