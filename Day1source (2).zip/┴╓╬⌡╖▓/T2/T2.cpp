#include<bits/stdc++.h>
using namespace std;
map<int,int> mp;
int a[1005];
int main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		mp[a[i]]++;
	}
	sort(a+1,a+n+1);
	int ans=0;
	for(int i=1;i<n;i++){
		for(int j=i+1;j<n;j++){
			int cha=a[j]-a[i];
			
			int sum=0;
			if(cha==0){
				if(mp[a[i]]>=4){
					sum+=(mp[a[i]]*(mp[a[i]]-1)*(mp[a[i]]-2)*(mp[a[i]]-3)/(4*3*2));
				}
			}else{
				sum=1;
				sum*=(mp[a[j]+cha]);
				sum*=(mp[a[j]+cha+cha]);
			}
			ans+=sum;
			sum=0;
			if(a[i]!=0&&a[j]!=0){
				double bi=a[j]*1.0/a[i];
				if(bi!=1){
					sum=1;
					int ll=bi*a[j];
					if(double(ll)==double(bi*a[j]))
						sum*=mp[ll];
					else
				 		sum*=0;
				 	ll*=bi;
					if(double(ll)==double(bi*bi*a[j]))
						sum*=mp[ll];
					else
					 	sum*=0;
				}
			}
			ans+=sum;
		}
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
