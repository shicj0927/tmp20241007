#include <bits/stdc++.h>
using namespace std;
#define N 290001
#define int long long
#define debug cout<<"**debug**\n";
#define pii pair<int,int>
#define endl '\n'
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define Rof(i,l,r) for(int i=l,i##end=r;i>=i##end;--i)
template <typename T> inline void rd(T &x){x = 0; bool f = true; char ch = getchar();while(ch < '0' || ch > '9')
{ if(ch == '-') f = false; ch = getchar();}while(ch >= '0' && ch <= '9'){ x = (x << 1) + (x << 3) + (ch ^ '0'); ch = getchar();}if(!f) x = -x;}
template <typename T, typename ...Args> inline void rd(T &x, Args &...args){ rd(x); rd(args...);}
multiset<int> se;
int now[N],cnt,ans;
struct answer{
	int a[4],sorted;
};
bool operator < (answer x, answer y) {
	if (!x.sorted)x.sorted=1,sort(x.a,x.a+4);
	if (!y.sorted)y.sorted=1,sort(y.a,y.a+4);
	return x.a[0]!=y.a[0]?x.a[0]<y.a[0]:x.a[1]!=y.a[1]?x.a[1]<y.a[1]:x.a[2]!=y.a[2]?x.a[2]<y.a[2]:x.a[3]<y.a[3];
}
map<int, int> cnttt;
void update(answer x){
	For(i, 0, 3) {
		cnttt[x.a[i]]=se.count(x.a[i]);
	}
	int dd=1;
	For(i, 0, 3){
		dd*=cnttt[x.a[i]];
		--cnttt[x.a[i]];
		dd/=se.count(x.a[i])-cnttt[x.a[i]];
	}
	ans+=dd;
}
int a[N];
bool cmp(int x, int y) {
	return abs(x)<abs(y);
}
map<int,int> vis;
set<answer> final;
void solve(){
	int n;cin>>n;
	For(i, 1, n) cin>>a[i],se.insert(a[i]);
	sort(a+1, a+n+1,cmp);
	int cntt=0;
	For(i, 1, n){
		For(j, i+1, n){
			double aa,bb;
			if (i==j) continue;
			int sec=a[i],trd=a[j],fst,lst;
			se.erase(se.find(a[i])),se.erase(se.find(a[j]));
//			if (a[i]==a[j]) {
//				if (!vis[a[i]])ans+=se.count(a[i])*(se.count(a[j])-1)/2;
//				vis[a[i]]=1;
//				goto endd;
//			}
			fst=a[i]-(a[j]-a[i]),lst=a[j]+(a[j]-a[i]);
			cnt=0;	
//debug;cout<<fst<<lst<<endl;
//				if (se.count(fst)*se.count(lst))	cout<<fst<<' '<<sec<<' '<<trd<<' '<<lst<<' '<<se.count(fst)*se.count(lst)<<endl;
//			update(fst,lst);
			final.insert({{fst,sec,trd,lst},0});
			if (sec==0||trd==0) goto endd;
			aa=sec*sec*1.0/trd,bb=trd*trd*1.0/sec;
			if (ceil(aa)==aa&&ceil(bb)==bb) {
				fst=aa,lst=bb;
//					if (se.count(fst)*se.count(lst))	cout<<fst<<' '<<sec<<' '<<trd<<' '<<lst<<' '<<se.count(fst)*se.count(lst)<<endl;
//				update(fst,lst);
//debug;cout<<fst<<lst<<endl;
				final.insert({{fst,sec,trd,lst},0});
			}
			endd:
			se.insert(a[i]),se.insert(a[j]);
		}
	}
	for (answer it:final){
		update(it);
//		For(i, 0, 3) cout<<it.a[i]<<' ';cout<<endl;
	}
	cout<<ans<<endl;
}
signed main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	solve();
	return 0;
}
