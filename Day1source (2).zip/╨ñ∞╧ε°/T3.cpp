#include<bits/stdc++.h>
using namespace std;
int n, q;
struct nn {
	int s, f;
	string u;
} a[5010];
struct node {
	int l, r, un;
};
map<string, node> mp; 
int main() {
	freopen("T3.in", "r", stdin);
	freopen("T3.out", "w", stdout);
	cin>>n>>q;
	for (int i=1; i<=n; i++) {
		cin>>a[i].s;
		a[i].u="AAA";
	}
	mp["AAA"].l=1, mp["AAA"].r=n, mp["AAA"].un=0;
	while (q--) {
		char op;
		int l, r, t, p, k; string s;
		cin>>op;
		if (op=='W') {
			cin>>l>>r>>t;
			int cnt1=0, cnt2=0;
			for (int i=l; i<=r; i++) 
				if (!a[i].f) {
					cnt1++;
					if (a[i].s<t) cnt2++, a[i].f=1;
					else a[i].s++;
				}
			cout<<cnt1<<' '<<cnt2<<'\n';
		} else if (op=='C') {
			cin>>s>>p;
			int u=s.size()-1, kl=mp[s].l, kr=mp[s].r; char r; string ss=s;
			if (s=="AAA") r='A';
			else {
				while (s[u]<'A'||s[u]>'Z') u--;
				r=s[u]+1;
			}
			s+='-';
			s+=r;
			mp[s].un++;
			s+=char(mp[s].un+'0');
			if (kr-kl+1<p) mp[s].un--, cout<<"ERR\n";
			else {
				mp[ss].l=kl+p, mp[s].l=kl, mp[s].r=kl+p-1;
				int cc=0;
				for (int i=kl; i<=kl+p-1; i++) {
					a[i].u=s;
					if (!a[i].f) cc++;
				}
				cout<<cc<<'\n';
			}
		} else if (op=='S') {
			cin>>p;
			if (a[p].f) cout<<"ERR\n";
			else cout<<a[p].u<<'\n';
		} else if (op=='E') {
			cin>>s;
			int cc=0;
			for (int i=mp[s].l; i<=mp[s].r; i++)
				if (!a[i].f) cc++;
			if (cc==0) cout<<"Oh no!\n";
			else cout<<cc<<'\n';
		} else if (op=='A') {
			cin>>l>>r>>k;
			int cnt=0;
			for (int i=l; i<=r; i++)
				if (a[i].f) cnt++, a[i].f=0, a[i].s=k;
			if (cnt==0) cout<<"no add\n";
			else if (cnt==1) cout<<"Add 1 soldier\n";
			else cout<<"Add "<<cnt<<" soldiers\n";
		}
	}
	return 0;
}

