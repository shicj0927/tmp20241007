#include<bits/stdc++.h>
using namespace std;
int main(){
	cout<<"Oh no!";
	return 0;
}
