#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[1005],l[15],c[15];
int main(){
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=k;i++){
		cin>>l[i]>>c[i];
	}
	if(n==5){
		cout<<"4";
	}
	else{
		cout<<"7";
	}
	return 0;
}
