#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	for(int i=1;i<=100;i++)
		cout<<"liangjindong0504 AK IOI!!!\n";
	for(int i=1;i<=100;i++)
		cout<<"mango2011 AK IOI!!!\n";
	for(int i=1;i<=100;i++)
		cout<<"lgx57 AK IOI!!!\n";
	for(int i=1;i<=100;i++)
		cout<<"zhlzt AK IOI!!!\n";
	for(int i=1;i<=100;i++)
		cout<<"__ikun__horro__ AK IOI!!!\n";
	fclose(stdin);
	fclose(stdout);
	return 0;
}
