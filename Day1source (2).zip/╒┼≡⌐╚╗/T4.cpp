#include<bits/stdc++.h>
using namespace std;
int liangjindong0504=1,AKIOI=3;
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cout<<liangjindong0504<<" "<<AKIOI;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
