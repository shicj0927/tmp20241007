#include<bits/stdc++.h>
using namespace std;
struct node
{
	int c,l;
}a[1010];
int n,m,k,b[1010];
int main()
{
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++)	scanf("%d",&b[i]);
	for(int i=1;i<=k;i++)	scanf("%d%d",&a[i].l,&a[i].c);
	cout<<"pool A!"<<endl;
}
