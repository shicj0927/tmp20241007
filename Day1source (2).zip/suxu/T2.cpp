#include<bits/stdc++.h>
using namespace std;
int n,a[1010];
int ans;
bool b(int x)
{
	int l=0,r=n+1;
	while(l+1<r)
	{
		int mid=l+r>>1;
		if(a[mid]<x) l=mid;
		else r=mid;
	}
	return a[l+1]==x;
}
int main()
{
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			{
				int k=a[j]-a[i];
				int o=-1;
				if(a[j]%a[i]==0&&a[i]!=0) o=a[j]/a[i];
				if(b(a[j]+k)&&b(a[j]+k+k)) ans++;
				if(o!=-1&&b(a[j]*o)&&b(a[j]*o*o)&&a[j]!=0&&o!=0&&a[i]!=0) ans++;
			}
	cout<<ans<<endl;
	return 0;
}
