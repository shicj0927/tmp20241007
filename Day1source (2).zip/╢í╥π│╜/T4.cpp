#include <bits/stdc++.h>
using namespace std;
int n,ans;
int a[500005],t[202],gt[202];
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		t[a[i]]++;
	}
	for(int i=n;i>=2;i--){
		int x=1,y=i;
		while(y<=n){
			for(int j=1;j<=200;j++)gt[j]=t[j];
			for(int j=1;j<x;j++)gt[a[j]]--;
			for(int j=y+1;j<=n;j++)gt[a[j]]--;
			int xt[202];
			memset(xt,0,sizeof(xt));
			for(int j=1;j<=200;j++){
				xt[gt[j]]++;
			}
			int k=201;
			while(k--){
				if(xt[k]!=0){
					if(xt[k]>=2){
						cout<<x<<" "<<y;
						return 0;
					}
					else break;
				}
			}
			x++,y++;
		}
	}
	cout<<-1;
	return 0;
}
