#include<bits/stdc++.h>
using namespace std;
int n,a[500005],cnt[205],ans,L,R;
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		for(int k=1;k<=200;k++) cnt[k]=0;
		for(int j=i;j<=n;j++){
			cnt[a[j]]++;
			if(i!=1&&j!=n&&a[i-1]!=a[j+1]) continue;
			int mx=0,res=0;
			for(int k=1;k<=200;k++){
				mx=max(mx,cnt[k]);
			}
			for(int k=1;k<=200;k++){
				if(cnt[k]==mx) res++;
			}
			if(res>1){
				if(j-i+1>ans){
					ans=j-i+1;
					L=i;
					R=j;
				}
			}
		}
	}
	if(ans==0) printf("-1");
	else printf("%d %d",L,R);
	return 0;
}
/*
2
1 1
5
1 2 3 3 4
*/
