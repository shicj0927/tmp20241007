#include<bits/stdc++.h>
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
const int N=5e5+5;
int a[N],b[N],m;
struct node{
	int ma,sma;
	int xxx,yyy; 
}t[N<<2];
int ls(int x){
	return x<<1;
}
int rs(int x){
	return x<<1|1;
}
node get(node x,node y){
	node ans={0,0,0,0};
	ans.ma=max(x.ma,y.ma);
	ans.sma=(x.ma<y.ma?max(y.sma,x.ma):max(x.sma,y.ma));
	if (x.ma==y.ma) ans.xxx=x.xxx+y.xxx;
	else ans.xxx=(x.ma>y.ma?x.xxx:y.xxx);
	int Ans=0;
	if (x.ma==y.ma){
		if (x.sma==y.sma) Ans=x.yyy+y.yyy;
		else if(x.sma<y.sma) Ans=y.yyy;
		else Ans=x.yyy;
	}
	else if (x.ma<y.ma){
		if (x.ma==y.sma) Ans=x.xxx+y.yyy;
		else if(x.ma<y.sma) Ans=y.yyy;
		else Ans=x.xxx;
	}
	else{
		if (x.sma==y.ma) Ans=x.yyy+y.xxx;
		else if (x.sma<y.ma) Ans=y.xxx;
		else Ans=x.yyy;
	}
	ans.yyy=Ans;
	return ans;
}
void push_up(int p){
	t[p]=get(t[ls(p)],t[rs(p)]);
}
void build(int p,int pl,int pr){
	if (pl==pr){
		t[p]={a[pl],-1,1,0};
		return ;
	}
	int mid=(pl+pr)>>1;
	build(ls(p),pl,mid);
	build(rs(p),mid+1,pr);
	push_up(p);
}
node query(int l,int r,int p,int pl,int pr){
	if (l<=pl&&pr<=r){
		return t[p];
	}
	int mid=(pl+pr)>>1;
	node ans={0,0,0,0};
	if (l<=mid) ans=get(ans,query(l,r,ls(p),pl,mid));
	if (r>mid) ans=get(ans,query(l,r,rs(p),mid+1,pr));
	return ans;
}
map<int,int> mp;
signed main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int n;
	cin>>n;
	for (int i=1;i<=n;i++) cin>>a[i];
	build(1,1,n);
	int l=1,r=1;
	int Ans=-1;
	int ans1=0,ans2=0;
	mp[a[1]]++;
	int la1=0,la2=0; 
	while (r<=n){
		node now=query(l,r,1,1,n);
//		cout<<"!!! "<<l<<' '<<r<<' '<<now.ma<<' '<<now.xxx<<endl;
		if (now.xxx>=2){
			if (Ans<r-l+1){
				Ans=r-l+1,ans1=l,ans2=r;
			}
			else if (Ans==r-l+1){
				if (ans1>l) ans1=l,ans2=r;
			}
		}
		int tmp=mp[a[l]];
		while (mp[a[l]]>=now.sma&&now.xxx==1&&l+1<=r){
			if (a[l]==tmp) now.ma--;
			mp[a[l]]--;
			l++;
		}
		now=query(l,r,1,1,n);
		while (r+1<=n&&query(l,r+1,1,1,n).xxx==1) r++;
		if (l==la1&&r==la2){
			l++,r++;
		}
		la1=l,la2=r;
	}
	if (Ans==-1) cout<<-1;
	else cout<<ans1<<' '<<ans2<<endl;
	return 0;
}
