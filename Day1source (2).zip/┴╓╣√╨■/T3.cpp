#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
const int N=500;
int a[N];
map<int,string> mp;
bool f[N];
map<string,vector<int> > o;
map<string,vector<srting> > v;
signed main(){
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int n,q;
	cin>>n>>q;
	for (int i=1;i<=n;i++) cin>>a[i];
	for (int i=1;i<=n;i++){
		mp[i]="AAA";
	}
	for (int i=1;i<=n;i++){
		o["AAA"].push_back(a[i]);
	}
	while (q--){
		char c;
		cin>>c;
		if (c=='W'){
			int l,r,t;
			cin>>l>>r>>t;
			int ans1=0,ans2=0;
			for (int i=l;i<=r;i++){
				if (a[i]<t) f[i]=0,ans2++;
				else a[i]++,ans1++;
			}
			cout<<ans1<<' '<<ans2<<endl;
		}
		if (c=='C'){
			string s;
			int x;
			cin>>s>>x;
			if (o[s].size()<x){
				cout<<"ERR"<<endl;
				continue;
			}
			string now=s+"-";
			string tt=v[s][v[s].size()-1];
			tt[0]++;
			now+=tt;
			v[s].push_back(tt);
			for (int i=0;i<x;i++){
				mp[o[s][i]]=tt;
				o[tt].push_back(o[s][i]);
				o[s].erase(*o[s][i]);
			}
		}
		if (c=='S'){
			int x;
			cin>>x;
			if (f[x]==0) cout<<"ERR";
			else{
				int ans=0;
				for (int xx:o[mp[x]]){
					if (xx<x) ans++;
				}
				cout<<mp[x]<<' '<<ans<<' '<<a[x]<<endl;
			}
		}
		if (c=='E'){
			string s;
			cin>>s;
			int ans=0;
			for (int x:o[s]){
				if (f[x]) ans++;
			}
			if (ans==0) cout<<"Oh no!";
			else cout<<ans;
			cout<<endl;
		}
		if (c=='A'){
			int l,r,k;
			cin>>l>>r>>k;
			int cnt=0;
			for (int i=l;i<=r;i++){
				if (f[i]) continue;
				f[i]=1;
				a[i]=k;
			}
			if (cnt==0){
				cout<<"no add";
			}
			else if (cnt==1){
				cout<<"Add 1 soldier";
			}
			else cout<<"Add "<<cnt<<' '<<"soldier";
			cout<<endl;
		}
	}
	return 0;
}
