#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1005;
int a[maxn],b[5],c[5];
bool vis[5];
bool f;
bool chk1(int i,int j,int k,int l){
	return (l-k==k-j)&&(k-j==j-i);
}
bool chk2(int i,int j,int k,int l){
	if((!i)||(!j)||(!k)||(!l)){
		return 0;
	}
	if(i*k==j*j&&j*l==k*k){
		return 1;
	}
	return 0;
}
void dfs(int x){
	if(f){
		return;
	}
	if(x>4){
		if(chk1(c[b[1]],c[b[2]],c[b[3]],c[b[4]])){
			f=1;
		}
		if(chk2(c[b[1]],c[b[2]],c[b[3]],c[b[4]])){
			f=1;
		}
		return;
	}
	for(int i=1;i<=4;i++){
		if(!vis[i]){
			vis[i]=1;
			b[x]=i;
			dfs(x+1);
			vis[i]=0;
		}
	}
}
bool check(int i,int j,int k,int l){
	c[1]=a[i],c[2]=a[j],c[3]=a[k],c[4]=a[l];
	f=0;
	memset(vis,0,sizeof(vis));
	dfs(1);
	return f;
}
signed main(){
//	freopen("�ǿչ۲�.in","r",stdin);
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	ios::sync_with_stdio(false),cin.tie(NULL),cout.tie(NULL);
	int n,ans=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(n<=50){
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				for(int k=j+1;k<=n;k++){
					for(int p=k+1;p<=n;p++){
						if(check(i,j,k,p)){
							ans++;
						}
					}
				}
			}
		}
	}else{
		map<int,int>mp;
		for(int i=1;i<=n;i++){
			mp[a[i]]++;
		} 
		for(int i=1;i<=n;i++){
			mp[a[i]]--;
			for(int j=1;j<=n;j++){
				if(a[i]==a[j]){
					continue;
				}
				if(a[i]<a[j]){
					continue;   
				}
				mp[a[j]]--;
				int p=a[i]-(a[j]-a[i]),q=a[j]+a[j]-a[i];
				ans+=mp[p]*mp[q];
				//dengbi
				if(a[i]&&a[j]){
					if(a[i]*a[i]%a[j]==0){
						int p=a[i]*a[i]/a[j];
						if(a[j]*a[j]%a[i]==0){
							int q=a[j]*a[j]/a[i];                                                                                                                                                                                 
							ans+=mp[p]*mp[q];                                                                                     
						}
					}
				}
				mp[a[j]]++;
			}
			mp[a[i]]++; 
		}
		for(int i=1;i<=n;i++){
			int t=mp[a[i]];
			mp[a[i]]=0;
			ans+=t*(t-1)*(t-2)*(t-3)/24; 
		}
	}
	cout<<ans<<endl;
	return 0;
}
