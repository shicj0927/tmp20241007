#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[1005],ret;
map<int,int> mp;
bool pd(int x){
	return x>=-1e9&&x<=1e9;
}
signed main(){
	freopen("T2.in","r",stdin);
	freopen("T2.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i],mp[a[i]+1e9]++;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			int l=a[j]-a[i];
			if(pd(a[j]+l)&&(pd(a[j]+2*l))){
				ret+=mp[a[j]+l+1e9]*mp[a[j]+2*l+1e9];
			}	
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(i!=j&&a[i]&&a[j]){
				mp[a[i]+1e9]--;
				mp[a[j]+1e9]--;
				int aj2=a[j]*a[j];
				if(aj2%a[i]==0&&pd(aj2/a[i])&&aj2*a[j]%(a[i]*a[i])==0&&pd(aj2*a[j]/a[i]/a[i])){
					ret+=mp[aj2/a[i]+1e9]*mp[aj2*a[j]/(a[i]*a[i])+1e9];
			
				}
				mp[a[i]+1e9]++;
				mp[a[j]+1e9]++;	
			}	
		}                       
	}
	cout<<ret;                                                                                                                                                              
	return 0;
}
