#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("T4.in","r",stdin);
	freopen("T4.out","w",stdout);
	cout<<"-1";
	return 0;
}
