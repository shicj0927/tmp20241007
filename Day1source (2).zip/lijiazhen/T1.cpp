#include<bits/stdc++.h>
using namespace std;
int n,m,k,l[1005],a[1005],t,vis[1005];
long long ans=999999999999,c[1005];
void x(int d,long long sum){
	while(a[d]==0&&d<=m)d++;
	if(d>m){
		if(sum<ans)ans=sum;
		return;
	}
	for(int i=0;i<k;i++){
		if(l[i]>m)vis[i]=1;
		if(vis[i]==0){
			vis[i]=1;
			x(d+l[i],sum+c[i]);
			vis[i]=0;
		}
	}
}
int main(){
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=0;i<n;i++)cin>>t,a[t]=1;
	for(int i=0;i<k;i++)cin>>l[i]>>c[i];
	x(1,0);
	cout<<ans;
	return 0;
}
