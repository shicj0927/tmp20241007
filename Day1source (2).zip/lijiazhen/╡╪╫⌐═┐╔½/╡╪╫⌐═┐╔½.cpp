#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("��שͿɫ.in","r",stdin);
	freopen("��שͿɫ.out","w",stdout);
	
	return 0;
}
