#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("�ǿչ۲�.in","r",stdin);
	freopen("�ǿչ۲�.out","w",stdout);
	
	return 0;
}
