#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
	freopen("T1.in","r",stdin);
	freopen("T1.out","w",stdout);
	printf("poor A!");
}
