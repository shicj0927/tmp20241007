#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
	freopen("T3.in","r",stdin);
	freopen("T3.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&x);
		a[x]=1;
	}
	for(i=1;i<=k;i++)
		scanf("%lld%lld",&b[i].x,&b[i].y);  
	for(i=1;i<=m;i++)
		for()
}
